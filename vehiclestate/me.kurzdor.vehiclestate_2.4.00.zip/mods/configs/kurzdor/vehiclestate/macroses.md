# Available macroses / Доступные макросы

Warning: don't copy macroses with ` symbol, only what's inside!
Внимание: не копируйте макросы с символом `, а только то что внутри!

## Aiming info template / Шаблон информации про сведение танка

- `%(aimingTime)s` - full aiming time | полное время сведения
- `%(aimingRemainingTime)s` - remaining aiming time | оставшееся время до полного сведения
- `%(c:aimingStatus)s` - color depending on status (not ready, almost ready, ready) | цвет в зависимости от готовности (не готов, почти и готов)
- `%(aimingProgress)s` - aiming progress in percents | прогресс сведения в процентах

## Cooling delay timer template / Шаблон таймера охлаждения орудия

- `%(coolingDelayTimeLeft)s` - remaining gun cooling delay time | оставшееся время охлаждения орудия

## Health info template / Шаблон информации про состояние прочности танка

- `%(health)s` - current player's vehicle HP level | текущий уровень ХП техники игрока
- `%(c:health)s` - color depending of current player's vehicle HP level | цвет в зависимости от текущего уровня ХП игрока
- `%(lostHealth)s` - lost player's vehicle HP (max HP minus current HP) | потерянное ХП техники игрока (максимальное ХП минус текущее)
- `%(maxHealth)s` - max player's vehicle HP level including all factors (improved hardening, field modernization, etc.) | максимальный уровень ХП с учётом всех факторов (улучшенная закалка, полевая модернизация и прочее) техники игрока
- `%(healthPercentage)s` - current player's vehicle HP percentage | текущее значение прочности техники игрока в процентах

## View range info template / Шаблон информации про обзор танка

- `%(viewRange)s` - current player's vehicle view range including crew skills, equipment and consumables | текущий обзор техники игрока с учётом навыков экипажа, оборудования и расходников

## Targeting info template / Шаблон информации про прицеливание

- `%(distance)s` - distance from the vehicle to the aiming point | расстояние от танка до точки прицеливания
- `%(dispersion)s` - aiming circle diameter at the aiming point | диаметр круга сведения в точке прицеливания
- `%(flightTime)s` - shell flight time to the aiming point | время полёта снаряда до точки прицеливания

## Shell info template / Шаблон информации про текущий снаряд танка

- `%(shellDamage)s` - current loaded shell damage | урон заряженного снаряда
- `%(shellDamageDispersion)s` - current loaded shell damage dispersion | разброс урона заряженного снаряда (с учётом +-25%)
- `%(shellPenetration)s` - current loaded shell penetration | пробитие заряженного снаряда
- `%(shellPenetrationDispersion)s` - current shell penetration with +-25% dispersion | разброс пробития заряженного снаряда (с учётом +-25%)
- `%(shellType)s` - current shell type | текущий тип заряженного снаряда
- `%(shellKind)s` - current shell kind (normal, premium or stun) | текущий тип заряженного снаряда (обычный, премиум или станящий)
- `%(c:shellKind)s` - current shell type color (normal, premium or stun) | цвет текущего типа заряженного снаряда (обычный, премиум или станящий)
- `%(shellSpeed)s` - current shell speed | скорость полёта заряженного снаряда
- `%(shellCaliber)s` - current shell caliber | калибр заряженного снаряда
- `%(shellSplash)s` - current HE shell explosion radius | радиус взрыва заряженного фугасного снаряда
- `%(gunElevation)s` - gun elevation | максимальный верхний угол вертикальной наводки танка
- `%(gunDepression)s` - gun depression | максимальный нижний угол вертикальной наводки танка
- `%(gunPitchLimits)s` - gun elevation and depression | углы вертикальной наводки танка
